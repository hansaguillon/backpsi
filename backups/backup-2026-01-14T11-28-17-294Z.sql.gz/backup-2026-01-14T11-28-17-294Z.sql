-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: clinical_db
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addenda`
--

DROP TABLE IF EXISTS `addenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addenda` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_f07bafb4e77f894abf45775160f` (`session_id`),
  KEY `FK_55236bcc420396eebc3db2a02dd` (`created_by`),
  CONSTRAINT `FK_55236bcc420396eebc3db2a02dd` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FK_f07bafb4e77f894abf45775160f` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addenda`
--

LOCK TABLES `addenda` WRITE;
/*!40000 ALTER TABLE `addenda` DISABLE KEYS */;
INSERT INTO `addenda` VALUES ('2b049466-3597-4ae1-b044-76f9f22e068e','me confundi en cosas, demostro cosas buenas','2025-12-26 13:01:10.069146','a7c852fc-80ea-47ae-8d9d-47a015d9f46c','error en el tipeo','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('3c44ccfa-8e6b-45df-811e-15d434ba5547','nueva prueba','2025-12-26 13:09:56.269251','a7c852fc-80ea-47ae-8d9d-47a015d9f46c','queria corfregir cosas','53f68688-da6f-11f0-9470-d8bbc1508cfb');
/*!40000 ALTER TABLE `addenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` enum('CREATE','EDIT','LOCK','ADDENDUM','ACCESS','LOGIN','LOGOUT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` enum('PATIENT','SESSION','ADDENDUM','SYSTEM') COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timestamp` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `entity_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_bd2726fd31b35443f2245b93ba0` (`user_id`),
  CONSTRAINT `FK_bd2726fd31b35443f2245b93ba0` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES ('04d1c895-bb6b-434a-9e48-08de213b172f','EDIT','PATIENT','',NULL,'2026-01-06 07:08:34.198101','3adc18a6-2073-4381-86f6-43c82e70d354','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('0d4987ee-3187-4bc2-bcfa-b2b62357e5c6','LOGIN','SYSTEM','',NULL,'2025-12-17 10:58:51.316558','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('1afc875b-ecea-4875-8c77-e85a95dc292a','LOGIN','SYSTEM','',NULL,'2026-01-06 07:05:51.760916','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('1c525b65-472e-4aa5-b6b0-f85087cb6ae5','CREATE','SESSION','Creación de sesión clínica',NULL,'2025-12-23 15:08:46.608936','9b54318d-fcbe-4ddd-82a4-8a0238d418fd','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('1c8562df-54d2-499d-bb5a-6f0e66c437bf','EDIT','PATIENT','',NULL,'2026-01-02 07:11:10.646516','d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('24369c0b-d192-4bc6-af92-fe06ee88a040','EDIT','PATIENT','',NULL,'2025-12-26 13:42:06.166334','d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('27e0f372-d195-4619-8aed-6fe33877bc8d','CREATE','ADDENDUM','Se creó una adenda',NULL,'2025-12-26 13:09:56.278237','3c44ccfa-8e6b-45df-811e-15d434ba5547','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('36237a55-b32c-4e39-b7d3-460fc7bc9368','CREATE','SESSION','Creación de sesión clínica',NULL,'2025-12-23 15:12:10.316320','d7ab0609-f5e0-496a-9ae7-c1a5581ac243','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('38d932e5-ed79-41fb-ab11-318bba23d592','CREATE','SESSION','Creación de sesión clínica',NULL,'2025-12-23 15:22:18.782095','1932b89c-9c0e-4ac4-a59c-5624f8d6ee3e','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('3b5b8d3d-d38b-4036-a522-96275e474774','LOGIN','SYSTEM','',NULL,'2025-12-17 10:54:58.508710','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('3c25aa69-c620-41f6-8531-e14e494017b2','CREATE','ADDENDUM','Se creó una adenda',NULL,'2025-12-26 13:01:10.080047','2b049466-3597-4ae1-b044-76f9f22e068e','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('4d787d60-77fd-4b4d-8462-8b1982110985','LOGIN','SYSTEM','',NULL,'2026-01-02 07:10:10.217860','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('51d6d7c8-156b-4a02-9480-186dc47b1097','LOGIN','SYSTEM','',NULL,'2026-01-07 07:28:16.525584','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('5324ef3b-100e-4a35-943c-8563818b7313','CREATE','SESSION','Creación de sesión clínica',NULL,'2025-12-23 15:21:51.648815','eb5aefc1-9019-4384-90d5-857aa16e5000','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('56124f36-9ee2-4ccf-b536-66d611fa1c4c','EDIT','PATIENT','',NULL,'2026-01-06 07:24:07.866306','3adc18a6-2073-4381-86f6-43c82e70d354','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('5b133900-03d0-409d-a5d6-b260dcc478e2','CREATE','PATIENT','',NULL,'2025-12-23 15:00:24.743895','3adc18a6-2073-4381-86f6-43c82e70d354','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('66d11c9f-e097-486f-96a9-7d24eeb81710','EDIT','PATIENT','',NULL,'2026-01-06 07:06:05.731745','3db0320a-1841-4204-ab49-ec8355e2ab81','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('723a13c6-82f2-42f1-9e78-125d1dc91772','LOGIN','SYSTEM','',NULL,'2025-12-23 14:57:40.827235','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('78d29045-4e03-4fed-848b-21188fd1c0aa','EDIT','PATIENT','',NULL,'2025-12-23 15:53:18.955342','d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('8417ac31-457f-4caa-a6d8-c98512cfe591','LOGIN','SYSTEM','',NULL,'2026-01-05 09:36:12.117226','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('8a42c191-2893-4b30-863b-676b712ef869','CREATE','PATIENT','',NULL,'2025-12-18 08:32:02.605660','3db0320a-1841-4204-ab49-ec8355e2ab81','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('9db0601c-cd4a-40b4-a76b-828246f2014c','LOGIN','SYSTEM','',NULL,'2025-12-18 07:18:27.594404','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('b8de1200-5ed1-497d-8dc5-618e4f927738','LOGIN','SYSTEM','',NULL,'2025-12-17 12:15:28.052173','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('be2087d6-ff27-4f7f-a365-9534c31d46f7','LOGIN','SYSTEM','',NULL,'2025-12-17 11:02:57.588914','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('c3668cd9-9758-47fd-800d-708906d49238','LOGIN','SYSTEM','',NULL,'2026-01-06 07:33:44.888741','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('d87fa976-641a-4069-baba-1ce7e46d07b9','LOGIN','SYSTEM','',NULL,'2025-12-17 11:03:36.450107','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('e2e01a4d-8fbb-4ce3-9711-4a14c68fa4dd','LOGIN','SYSTEM','',NULL,'2025-12-26 13:00:01.232262','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('eaea3c87-5054-48df-bdd9-ef8438c2bdab','CREATE','SESSION','Creación de sesión clínica',NULL,'2025-12-23 15:07:14.899235','18db791c-7163-46e0-b44a-bc6b02b49d44','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('f295b4b4-ada2-4ef1-ad43-e639c687926b','EDIT','PATIENT','',NULL,'2025-12-23 15:53:30.153561','d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','53f68688-da6f-11f0-9470-d8bbc1508cfb'),('f5e138e8-8ecd-41be-9c6b-b5394be8b0bb','LOGIN','SYSTEM','',NULL,'2026-01-07 07:19:44.019364','53f68688-da6f-11f0-9470-d8bbc1508cfb','53f68688-da6f-11f0-9470-d8bbc1508cfb');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dni` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birth_date` date NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admission_date` date NOT NULL,
  `referral_source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consult_reason` text COLLATE utf8mb4_unicode_ci,
  `treatment_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `discharge_date` date DEFAULT NULL,
  `discharge_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_b09e471222674eb27a9ed8881b` (`dni`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES ('3adc18a6-2073-4381-86f6-43c82e70d354','Maria Magali','Asenjo','38741852','1995-08-08','2983562389','2025-12-23','Clarita','','','2025-12-23 15:00:24.717073','2026-01-06 07:24:07.000000','magaliasenjo@gmail.com','37387418521','inactive','2026-01-06','Alta terapéutica'),('3db0320a-1841-4204-ab49-ec8355e2ab81','Maria Paula','Asenjo','33843725','1988-10-25','298335640','2025-12-18','flor A','','','2025-12-18 08:32:02.590739','2025-12-18 08:32:02.590739','mpasenjo@yahoo.com','2720354127211','active',NULL,NULL),('d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','Juan Pedro','Aguillon M','35412721','1990-12-09','2983346206','2025-12-18','Alguien','se porta mal','','2025-12-18 08:22:47.052276','2026-01-02 07:11:10.000000','hansaguillon@gmail.com','20354127211','active',NULL,NULL);
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `important_events` text COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `is_locked` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `patient_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locked_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_b53ef4073197ef9be0c1d914c54` (`patient_id`),
  CONSTRAINT `FK_b53ef4073197ef9be0c1d914c54` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('10ff8309-cf2d-4a6c-9d67-ed41fb1196ca','hoy estuvo muy bien!! puedo modificaaaar','todo bien','[]',1,'2025-12-26 13:08:53.033523','d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','2025-12-26 16:41:40'),('18db791c-7163-46e0-b44a-bc6b02b49d44','Hola','HOla',NULL,1,'2025-12-23 15:07:14.886301','3adc18a6-2073-4381-86f6-43c82e70d354','2025-12-23 18:50:36'),('1932b89c-9c0e-4ac4-a59c-5624f8d6ee3e','cosas nuevas','cosas nuevas 2',NULL,1,'2025-12-23 15:22:18.771138','3db0320a-1841-4204-ab49-ec8355e2ab81','2025-12-26 16:09:35'),('21bf31d5-45fb-47c5-9d42-5d0fa6a662c9','prueba nueva','algo funciona?','[]',1,'2025-12-23 15:38:58.898248','3db0320a-1841-4204-ab49-ec8355e2ab81','2025-12-26 16:09:35'),('3f77a719-daf2-4336-9612-f1b7202b046a','Hola','HOla',NULL,1,'2025-12-23 15:06:48.429884','3adc18a6-2073-4381-86f6-43c82e70d354','2025-12-23 18:50:36'),('47c43bbb-7036-4c2e-9b6b-e182560fa4d9','Hola','HOla',NULL,1,'2025-12-23 15:00:59.518570','3adc18a6-2073-4381-86f6-43c82e70d354','2025-12-23 18:50:36'),('69487860-5155-4b2a-9bbe-3c6b32e33608','Hola','HOla',NULL,1,'2025-12-23 15:01:09.378455','3adc18a6-2073-4381-86f6-43c82e70d354','2025-12-23 18:50:36'),('834c46f8-5c5d-458f-82ba-e0dca8504afa','Hola','HOla',NULL,1,'2025-12-23 15:04:29.719825','3adc18a6-2073-4381-86f6-43c82e70d354','2025-12-23 18:50:36'),('89f80083-cd97-4f58-9d00-0cc8ad96b614','todo bien hoy',NULL,'[]',1,'2025-12-23 15:39:27.063291','d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','2025-12-23 18:50:44'),('9b54318d-fcbe-4ddd-82a4-8a0238d418fd','hola','hola',NULL,1,'2025-12-23 15:08:46.596901','3db0320a-1841-4204-ab49-ec8355e2ab81','2025-12-26 16:09:35'),('a7c852fc-80ea-47ae-8d9d-47a015d9f46c','nueva sesion 2','ahora funciona?','[]',1,'2025-12-23 15:50:49.953176','d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','2025-12-26 16:00:38'),('aa0b0402-b833-4019-b0fc-8843482ebfd2','hoy esta todo bien, y vuelve algun dia','todo normal','[]',1,'2026-01-02 07:11:35.424220','d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','2026-01-02 10:21:36'),('d7ab0609-f5e0-496a-9ae7-c1a5581ac243','Hola soy nuevo','nada',NULL,1,'2025-12-23 15:12:10.299853','d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','2025-12-23 18:50:44'),('eb5aefc1-9019-4384-90d5-857aa16e5000','hola','hola',NULL,1,'2025-12-23 15:21:51.639727','3db0320a-1841-4204-ab49-ec8355e2ab81','2025-12-26 16:09:35'),('f61e8201-318e-4e01-9502-049175aed41e','holña','hola',NULL,1,'2025-12-18 08:30:32.903191','d8b13e17-b18a-4ab4-b1de-ed0bfb36ca2d','2025-12-23 18:50:44');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('psychologist') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'psychologist',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_fe0bb3f6520ee0469504521e71` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('53f68688-da6f-11f0-9470-d8bbc1508cfb','magali.asenjo','$2b$10$zqYzG3KgtntpnzNC/X3XcO7DByGcBq6qsVI6FbDleEP0kuhU1PEJK','Lic. María Magali Asenjo','psychologist','2025-12-16 08:06:53.000000','2026-01-07 07:28:16.000000','2026-01-07 10:28:17');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-14  8:28:17
