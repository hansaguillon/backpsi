-- MySQL dump 10.13  Distrib 8.4.8, for Win64 (x86_64)
--
-- Host: localhost    Database: clinical_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addenda`
--

DROP TABLE IF EXISTS `addenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addenda` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `session_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_session_id` (`session_id`),
  CONSTRAINT `addenda_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addenda_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addenda`
--

LOCK TABLES `addenda` WRITE;
/*!40000 ALTER TABLE `addenda` DISABLE KEYS */;
INSERT INTO `addenda` VALUES ('8f5612e4-edaf-4dba-b4f2-9cad5ec70b29','304cd608-2b94-4b3c-b260-98aa2b49a775','me mintio si le dolia mucho','ESCRIBIR MAL','6431ac00-224b-11f1-8670-88d7f6a1ecf6','2026-03-17 19:36:57');
/*!40000 ALTER TABLE `addenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `action` enum('CREATE','EDIT','LOCK','ADDENDUM','ACCESS','LOGIN','LOGOUT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` enum('PATIENT','SESSION','ADDENDUM','SYSTEM') COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_entity` (`entity_type`,`entity_id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES ('52c78813-8b5f-46cb-a34e-f165fc228481','CREATE','ADDENDUM','8f5612e4-edaf-4dba-b4f2-9cad5ec70b29','Se creó una adenda','6431ac00-224b-11f1-8670-88d7f6a1ecf6',NULL,'2026-03-17 19:36:57'),('8c2ed57d-fa8d-42aa-878d-fdbbff37272f','LOGIN','SYSTEM','6431ac00-224b-11f1-8670-88d7f6a1ecf6','','6431ac00-224b-11f1-8670-88d7f6a1ecf6','127.0.0.1','2026-03-17 18:53:38'),('d728db50-6ce1-4016-b01f-41b21cd1609a','CREATE','PATIENT','c9db51b9-f92e-40db-8bb8-3406732bcd34','','6431ac00-224b-11f1-8670-88d7f6a1ecf6',NULL,'2026-03-17 18:54:34'),('e44f9227-4619-4d2d-aee6-366546180324','LOGIN','SYSTEM','6431ac00-224b-11f1-8670-88d7f6a1ecf6','','6431ac00-224b-11f1-8670-88d7f6a1ecf6','127.0.0.1','2026-03-17 19:19:43'),('ef41ab46-b1a5-4d13-b143-7dede8469720','LOGIN','SYSTEM','6431ac00-224b-11f1-8670-88d7f6a1ecf6','','6431ac00-224b-11f1-8670-88d7f6a1ecf6','127.0.0.1','2026-03-17 19:05:12');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exercise_plans`
--

DROP TABLE IF EXISTS `exercise_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exercise_plans` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `patient_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Rutina de Ejercicios',
  `days_per_week` tinyint unsigned NOT NULL DEFAULT '3',
  `days` json NOT NULL,
  `observations` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_patient_id` (`patient_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `exercise_plans_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exercise_plans_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercise_plans`
--

LOCK TABLES `exercise_plans` WRITE;
/*!40000 ALTER TABLE `exercise_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `exercise_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dni` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birth_date` date NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admission_date` date NOT NULL,
  `referral_source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consult_reason` text COLLATE utf8mb4_unicode_ci,
  `treatment_notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `discharge_date` date DEFAULT NULL,
  `discharge_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dni` (`dni`),
  KEY `idx_dni` (`dni`),
  KEY `idx_last_name` (`last_name`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES ('c9db51b9-f92e-40db-8bb8-3406732bcd34','Juan Pedro','Aguillon','35412721','1990-12-06','2983346206','hansaguillon@gmail.com','2026-03-17','nadie','20354127211','chequeo ',NULL,'active',NULL,NULL,'2026-03-17 18:54:34','2026-03-17 18:54:34');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_attachments`
--

DROP TABLE IF EXISTS `session_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_attachments` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `session_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_session_id` (`session_id`),
  CONSTRAINT `session_attachments_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_attachments`
--

LOCK TABLES `session_attachments` WRITE;
/*!40000 ALTER TABLE `session_attachments` DISABLE KEYS */;
INSERT INTO `session_attachments` VALUES ('8aa38343-031e-4c49-961e-2ece1ff69ddd','43c194d5-d7b5-4145-ac26-0362e963b7b9','/uploads/1773786002175-912b312d-cb1c-488d-bc9b-cfe81aec51c4.jpg','IMG-20250623-WA0072.jpg','image/jpeg',420670,'2026-03-17 19:20:02');
/*!40000 ALTER TABLE `session_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `patient_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `important_events` text COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `vital_signs` json DEFAULT NULL,
  `diagnosis` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prescription` text COLLATE utf8mb4_unicode_ci,
  `studies` text COLLATE utf8mb4_unicode_ci,
  `kinesic_plan` json DEFAULT NULL,
  `evolution` text COLLATE utf8mb4_unicode_ci,
  `is_locked` tinyint(1) DEFAULT '0',
  `locked_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_patient_id` (`patient_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('304cd608-2b94-4b3c-b260-98aa2b49a775','c9db51b9-f92e-40db-8bb8-3406732bcd34','Todo perfecto',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-03-17 19:05:06','2026-03-17 18:55:06','2026-03-17 19:05:06'),('43c194d5-d7b5-4145-ac26-0362e963b7b9','c9db51b9-f92e-40db-8bb8-3406732bcd34','imagen',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-03-17 19:33:27','2026-03-17 19:20:02','2026-03-17 19:33:27'),('5f55a0b2-a97b-491c-bac3-a7d5a69265ba','c9db51b9-f92e-40db-8bb8-3406732bcd34','Segunda sesion','hoy mejoro',NULL,'{\"height\": 182, \"weight\": 93, \"heartRate\": 72, \"temperature\": 36, \"bloodPressure\": \"120/80\", \"respiratoryRate\": 16, \"oxygenSaturation\": 98}','Todo en orden','reposo','laboratoro',NULL,NULL,1,'2026-03-17 19:19:29','2026-03-17 19:08:20','2026-03-17 19:19:29');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('psychologist','doctor','kinesiologist') COLLATE utf8mb4_unicode_ci DEFAULT 'psychologist',
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('64311122-224b-11f1-8670-88d7f6a1ecf6','magali.asenjo','$2b$10$zqYzG3KgtntpnzNC/X3XcO7DByGcBq6qsVI6FbDleEP0kuhU1PEJK','Lic. María Magali Asenjo','psychologist',NULL,'2026-03-17 18:51:02','2026-03-17 18:51:02'),('6431ac00-224b-11f1-8670-88d7f6a1ecf6','doctor','$2b$10$zqYzG3KgtntpnzNC/X3XcO7DByGcBq6qsVI6FbDleEP0kuhU1PEJK','Dr. Juan Pérez','doctor','2026-03-17 19:19:44','2026-03-17 18:51:02','2026-03-17 19:19:43'),('6431ae53-224b-11f1-8670-88d7f6a1ecf6','kinesio','$2b$10$zqYzG3KgtntpnzNC/X3XcO7DByGcBq6qsVI6FbDleEP0kuhU1PEJK','Lic. Carlos Gómez','kinesiologist',NULL,'2026-03-17 18:51:02','2026-03-17 18:51:02');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-17 20:20:00
