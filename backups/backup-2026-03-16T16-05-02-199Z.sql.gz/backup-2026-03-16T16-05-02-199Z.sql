-- MySQL dump 10.13  Distrib 8.4.6, for Win64 (x86_64)
--
-- Host: localhost    Database: clinical_db
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addenda`
--

DROP TABLE IF EXISTS `addenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addenda` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `session_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_session_id` (`session_id`),
  CONSTRAINT `addenda_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addenda_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addenda`
--

LOCK TABLES `addenda` WRITE;
/*!40000 ALTER TABLE `addenda` DISABLE KEYS */;
/*!40000 ALTER TABLE `addenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `action` enum('CREATE','EDIT','LOCK','ADDENDUM','ACCESS','LOGIN','LOGOUT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` enum('PATIENT','SESSION','ADDENDUM','SYSTEM') COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_entity` (`entity_type`,`entity_id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES ('046adfe7-99da-42cc-9cfe-109fbbec4b01','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-03-03 10:10:08'),('09f35b50-a293-45c4-bdf9-4fea6693248b','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','127.0.0.1','2026-03-16 09:27:33'),('12e32ebb-06ae-4cf5-a167-93da62098937','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-27 09:09:36'),('169120f2-78cf-4de4-a417-91eab179396b','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-30 11:33:04'),('176a5b41-42ba-4cbe-be69-298394cd02a4','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-28 08:26:05'),('188772d6-0408-4a06-aeea-2fcdf9e1777a','LOGIN','SYSTEM','9812bad1-2151-11f1-86ad-d8bbc1508cfb','','9812bad1-2151-11f1-86ad-d8bbc1508cfb','127.0.0.1','2026-03-16 13:03:28'),('1f2b2926-ffa5-4536-bae6-79eaf4a0bea5','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-05 07:58:11'),('1f9570bd-38f7-44bc-8eff-a303138ef65e','CREATE','PATIENT','cd00aa74-8148-46da-bdfd-0b87881bce37','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-27 09:10:46'),('31d803f7-c3d4-4753-8800-f09a155f29d2','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-28 08:25:53'),('3fc707c0-abfa-433a-bc88-cf7b82bb3a64','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb','172.16.21.228','2026-03-16 12:44:41'),('42bff858-9e07-4b9e-94d8-d1239d829ded','LOGIN','SYSTEM','e6757018-fb74-11f0-92a8-d8bbc1508cfb','','e6757018-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-27 09:11:56'),('457924f5-c2cd-4ae2-b1b3-2d4ecd58ab89','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-03 07:48:37'),('46f8eef7-8488-4862-b507-ce03fe4242a4','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-10 14:53:55'),('5089562a-b608-4289-81e8-bb1065319960','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-28 11:07:03'),('56e62580-e0bd-486f-8d67-ed9b57faaeb7','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-10 14:49:56'),('702b9c40-f4be-4114-ba03-99ff0b89e329','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','172.16.21.228','2026-03-16 12:39:48'),('7ff46fb7-9e30-4bd2-95e8-dd3203ee7e80','EDIT','PATIENT','cd00aa74-8148-46da-bdfd-0b87881bce37','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-29 12:59:01'),('86b369b5-dd65-47d4-927a-5e3aa5ccdbd1','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-29 12:57:46'),('89467cb9-19e3-435f-adc7-b2c247f5e3ef','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-10 14:47:48'),('8e69147e-8ccd-402c-9783-b212561655af','EDIT','PATIENT','cd00aa74-8148-46da-bdfd-0b87881bce37','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-29 12:59:35'),('91cb156e-37bb-4a75-9549-c520411e8f78','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-04 08:20:33'),('9395c069-caf4-464e-9446-cd7ee8e8279f','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-29 12:59:16'),('976ccedf-37e6-4f3c-a376-fbf47b1fdbc7','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb','172.16.21.228','2026-03-16 12:14:20'),('9dc54400-42fb-4a5a-ab4a-c7a1d3461dc8','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb','172.16.21.228','2026-03-16 12:29:30'),('a0cbebd2-e776-45a8-89b0-113ecc0bc16a','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-10 15:00:26'),('a16cc840-bb79-4f0c-8ae8-bec1864dbd41','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-27 09:11:37'),('ad24f6a6-cace-4631-b72c-38c5ccd2227f','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','172.16.21.228','2026-03-16 12:15:37'),('b024d260-30d4-4ac5-89ac-9ba0ce7637e2','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-03-02 12:03:46'),('caee6229-106a-4cba-b7b5-7767aadde9af','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-10 15:19:50'),('d8adf146-7aec-4fd2-be2b-d03dbbcebd35','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-05 07:44:13'),('e19e6829-1200-48ce-8c19-cde522c23611','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-10 14:54:49'),('ed442dac-d9ce-440b-960b-dcca123eb677','LOGIN','SYSTEM','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','','e67576d1-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-01-27 09:17:48'),('f6418824-b7cc-4e8b-96b7-efb7ceab0c64','LOGIN','SYSTEM','e6753724-fb74-11f0-92a8-d8bbc1508cfb','','e6753724-fb74-11f0-92a8-d8bbc1508cfb',NULL,'2026-02-06 10:16:55');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exercise_plans`
--

DROP TABLE IF EXISTS `exercise_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exercise_plans` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `patient_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Rutina de Ejercicios',
  `days_per_week` tinyint unsigned NOT NULL DEFAULT '3',
  `days` json NOT NULL,
  `observations` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_ep_patient_id` (`patient_id`),
  KEY `idx_ep_status` (`status`),
  CONSTRAINT `exercise_plans_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exercise_plans_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercise_plans`
--

LOCK TABLES `exercise_plans` WRITE;
/*!40000 ALTER TABLE `exercise_plans` DISABLE KEYS */;
INSERT INTO `exercise_plans` VALUES ('ee8344fa-439b-4f06-8eef-8e7dbb6204b3','cd00aa74-8148-46da-bdfd-0b87881bce37','e67576d1-fb74-11f0-92a8-d8bbc1508cfb','Rutina de Ejercicios',3,'[{\"id\": \"ef34e49e-03a4-4b8c-8831-2da024ef4e54\", \"label\": \"Día 1\", \"exercises\": [{\"id\": \"a5bf4de9-bf02-486c-82fa-5ca88552293e\", \"name\": \"a\", \"reps\": \"10\", \"rest\": \"60d\", \"sets\": \"3\", \"notes\": \"\"}, {\"id\": \"5b1e574b-13d2-4cf3-8e95-9ae86039aa14\", \"name\": \"\", \"reps\": \"\", \"rest\": \"\", \"sets\": \"\", \"notes\": \"\"}]}, {\"id\": \"2e2ed32c-bc33-4c28-9ff7-420f98954ca5\", \"label\": \"Día 2\", \"exercises\": [{\"id\": \"9afc5f0e-14c7-467d-baf5-acf079f49b00\", \"name\": \"fdsafsd\", \"reps\": \"10\", \"rest\": \"45\", \"sets\": \"3\", \"notes\": \"\"}, {\"id\": \"0c97f643-2614-486c-b7d2-23e730ac6a51\", \"name\": \"\", \"reps\": \"\", \"rest\": \"\", \"sets\": \"\", \"notes\": \"\"}]}, {\"id\": \"fdb502bf-4fdb-4d8b-864b-e4971abbfeff\", \"label\": \"Día 3\", \"exercises\": [{\"id\": \"594f5096-90f8-445b-9cc3-1c3873288407\", \"name\": \"cosas\", \"reps\": \"2\", \"rest\": \"80\", \"sets\": \"1\", \"notes\": \"\"}, {\"id\": \"bb0ceef9-9556-455b-8786-6dc0db1b917c\", \"name\": \"\", \"reps\": \"\", \"rest\": \"\", \"sets\": \"\", \"notes\": \"\"}]}]','','active','2026-03-16 09:29:40','2026-03-16 09:35:11');
/*!40000 ALTER TABLE `exercise_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dni` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birth_date` date NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admission_date` date NOT NULL,
  `referral_source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consult_reason` text COLLATE utf8mb4_unicode_ci,
  `treatment_notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `discharge_date` date DEFAULT NULL,
  `discharge_reason` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dni` (`dni`),
  KEY `idx_dni` (`dni`),
  KEY `idx_last_name` (`last_name`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES ('cd00aa74-8148-46da-bdfd-0b87881bce37','Juan Pedro','Aguillon','35412721','1990-12-09','2983346206','hansaguillon@gmail.com','2026-01-27','nadie','20354127211',NULL,NULL,'active','2026-01-29','Derivación','2026-01-27 09:10:46','2026-01-29 12:59:35');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_attachments`
--

DROP TABLE IF EXISTS `session_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_attachments` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `session_attachments_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_attachments`
--

LOCK TABLES `session_attachments` WRITE;
/*!40000 ALTER TABLE `session_attachments` DISABLE KEYS */;
INSERT INTO `session_attachments` VALUES ('6923b9dd-0527-4347-9249-de01a4a4fa3d','31f21577-5682-4a51-8530-9f310ef802a5','/uploads/1770746066880-7e2fde43-9730-43ff-bc54-dba3836cd948.jpeg','WhatsApp Image 2025-10-16 at 08.22.49.jpeg','image/jpeg',70444,'2026-02-10 17:54:26'),('7baa75c8-70f6-4b1f-b5cb-8b9e63e60a02','47436bbb-68b8-4615-b5e9-133e5886040e','/uploads/1769785950638-9fc2cbef-ab3b-417a-8498-57fab9aabf52.jpeg','WhatsApp Image 2025-10-16 at 08.22.49.jpeg','image/jpeg',70444,'2026-01-30 15:12:30'),('96de0788-d6bb-40d3-a33d-259101e1428d','03331d01-5da7-4ed6-885a-2b4561c54fa3','/uploads/1769785880813-62a67c66-668d-4972-8f67-c26bd04b01e5.pdf','GUIA-CURSO-IA-2026-DIA-1.pdf','application/pdf',15660526,'2026-01-30 15:11:20'),('af1beea2-065c-48e4-98fa-2afd84110ff8','03331d01-5da7-4ed6-885a-2b4561c54fa3','/uploads/1769785862658-53ba118a-241c-48c0-800d-7b62883be366.jpg','descarga (11).jpg','image/jpeg',4125,'2026-01-30 15:11:02'),('fb22ad7c-168a-484c-b5ba-d7fa78c38e3e','47436bbb-68b8-4615-b5e9-133e5886040e','/uploads/1769786003728-df67741c-e16a-427a-b07a-080fb9315dae.pdf','GUIA-CURSO-IA-2026-DIA-1.pdf','application/pdf',15660526,'2026-01-30 15:13:23');
/*!40000 ALTER TABLE `session_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `patient_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `important_events` text COLLATE utf8mb4_unicode_ci,
  `vital_signs` json DEFAULT NULL,
  `diagnosis` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prescription` text COLLATE utf8mb4_unicode_ci,
  `studies` text COLLATE utf8mb4_unicode_ci,
  `kinesic_plan` json DEFAULT NULL,
  `evolution` text COLLATE utf8mb4_unicode_ci,
  `is_locked` tinyint(1) DEFAULT '0',
  `locked_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_patient_id` (`patient_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('03331d01-5da7-4ed6-885a-2b4561c54fa3','cd00aa74-8148-46da-bdfd-0b87881bce37','prueba 4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-02-03 07:48:44','2026-01-30 12:11:02','2026-02-03 07:48:44'),('20b569cd-e216-4142-b80f-207347bae727','cd00aa74-8148-46da-bdfd-0b87881bce37','Rodilla con dolor','siente dolor cuando se agacha',NULL,NULL,NULL,NULL,'{\"exercises\": \"Isométricos de Cuádriceps: Sentado o acostado, coloque una toalla enrollada bajo la rodilla y apriete fuertemente la rodilla contra la toalla durante 5 segundos, relaje y repita 10 veces.\\nElevación de Pierna Recta: Boca arriba, mantenga una pierna estirada y levántela (aprox. 30 cm) manteniendo la rodilla recta durante 5 segundos, baje lentamente. 3 series de 10-15 repeticiones.\\nPuente de Glúteos: Boca arriba, con rodillas dobladas, eleve la pelvis manteniendo la espalda recta. Fortalece glúteos y estabiliza la rodilla.\\nEstiramiento de Isquiotibiales: Sentado al borde de una silla, estire una pierna e inclínese suavemente hacia adelante, manteniendo la posición 20 segundos.\\nTalón al Glúteo: De pie, apoyado en una silla, lleve el talón hacia el glúteo para estirar el cuádriceps, manteniendo 10-30 segundos. \"}','segunda sesion con mas movilidad ',1,'2026-01-28 09:19:22','2026-01-28 09:09:15','2026-01-28 09:19:21'),('22396245-646d-4446-9c81-55e9c03a27dc','cd00aa74-8148-46da-bdfd-0b87881bce37','Se nota bien',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-28 08:26:22','2026-01-27 09:13:56','2026-01-28 08:26:21'),('30b2035b-eec3-4c87-b2ef-dbfa835670e5','cd00aa74-8148-46da-bdfd-0b87881bce37','Hoy bien ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-03-16 12:55:40','2026-03-16 12:44:16','2026-03-16 12:55:40'),('31f21577-5682-4a51-8530-9f310ef802a5','cd00aa74-8148-46da-bdfd-0b87881bce37','Hoy muy bien','ninguno',NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-02-10 15:04:26','2026-02-10 14:54:26','2026-02-10 15:04:26'),('47436bbb-68b8-4615-b5e9-133e5886040e','cd00aa74-8148-46da-bdfd-0b87881bce37','hola ola subo imagenes ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-02-03 07:48:44','2026-01-30 12:12:30','2026-02-03 07:48:44'),('55d16b5c-fe04-4c6a-8e63-39f75a8f81fc','cd00aa74-8148-46da-bdfd-0b87881bce37','prueba de subir imagen','suibir la imagen',NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-30 11:44:32','2026-01-30 11:33:36','2026-01-30 11:44:32'),('6cce3ca0-d691-4410-abc0-8c4b126c7f90','cd00aa74-8148-46da-bdfd-0b87881bce37','prueba 2','prueba 2',NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-30 11:51:54','2026-01-30 11:41:45','2026-01-30 11:51:54'),('a21c2a64-d91b-4595-a122-4cd184ddea35','cd00aa74-8148-46da-bdfd-0b87881bce37','prueba 3','vamso por la 3',NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-30 12:10:32','2026-01-30 11:59:38','2026-01-30 12:10:32'),('c2eb4931-ad7f-4390-94a1-0bae45c17056','cd00aa74-8148-46da-bdfd-0b87881bce37','se movio mas','ninguno',NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-28 08:38:22','2026-01-28 08:28:19','2026-01-28 08:38:21');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (uuid()),
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('psychologist','doctor','kinesiologist','admin') COLLATE utf8mb4_unicode_ci DEFAULT 'psychologist',
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('9812bad1-2151-11f1-86ad-d8bbc1508cfb','admin','$2b$10$zqYzG3KgtntpnzNC/X3XcO7DByGcBq6qsVI6FbDleEP0kuhU1PEJK','Administración','admin','2026-03-16 13:03:29','2026-03-16 13:02:55','2026-03-16 13:03:28'),('e6753724-fb74-11f0-92a8-d8bbc1508cfb','magali.asenjo','$2b$10$zqYzG3KgtntpnzNC/X3XcO7DByGcBq6qsVI6FbDleEP0kuhU1PEJK','Lic. María Magali Asenjo','psychologist','2026-03-16 12:44:41','2026-01-27 08:39:54','2026-03-16 12:44:41'),('e6757018-fb74-11f0-92a8-d8bbc1508cfb','doctor','$2b$10$zqYzG3KgtntpnzNC/X3XcO7DByGcBq6qsVI6FbDleEP0kuhU1PEJK','Dr. Juan Pérez','doctor','2026-01-27 09:11:56','2026-01-27 08:39:54','2026-01-27 09:11:56'),('e67576d1-fb74-11f0-92a8-d8bbc1508cfb','kinesio','$2b$10$zqYzG3KgtntpnzNC/X3XcO7DByGcBq6qsVI6FbDleEP0kuhU1PEJK','Lic. Carlos Gómez','kinesiologist','2026-03-16 12:39:48','2026-01-27 08:39:54','2026-03-16 12:39:48');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-16 13:05:02
